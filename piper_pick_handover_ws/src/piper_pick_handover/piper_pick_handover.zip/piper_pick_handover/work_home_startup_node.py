#!/usr/bin/env python3
import os
import threading
import time
from pathlib import Path

import rclpy

from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Bool
from std_srvs.srv import SetBool


class WorkHomeStartupNode(Node):
    """
    Startup phase BEFORE MoveIt:

        agx_arm_ctrl starts
            ↓
        explicitly OPEN /control_enable
            ↓
        direct JointState command -> WORK_HOME
            ↓
        verify real /feedback/joint_states
            ↓
        explicitly CLOSE /control_enable
            ↓
        write ready sentinel + exit

    The launch file starts MoveIt only AFTER this process exits
    successfully. MoveIt then starts with auto_control_gate:=true.

    This node controls joint1~joint6 only. It never commands the gripper.
    """

    def __init__(self):
        super().__init__("work_home_startup_node")

        self.cb_group = ReentrantCallbackGroup()
        self.feedback_lock = threading.Lock()

        self.declare_parameter(
            "joint_names",
            [
                "joint1",
                "joint2",
                "joint3",
                "joint4",
                "joint5",
                "joint6",
            ],
        )

        self.declare_parameter(
            "work_home_positions",
            [
                0.6047216792309954,
                0.5739340712258153,
                -1.269657217655795,
                1.5629947050384818,
                0.030944687637859465,
                -0.11095058054927953,
            ],
        )

        self.declare_parameter(
            "feedback_topic",
            "/feedback/joint_states",
        )
        self.declare_parameter(
            "control_topic",
            "/control/joint_states",
        )
        self.declare_parameter(
            "control_gate_service",
            "/control_enable",
        )

        self.declare_parameter(
            "feedback_wait_timeout_sec",
            10.0,
        )
        self.declare_parameter(
            "move_timeout_sec",
            30.0,
        )
        self.declare_parameter(
            "command_rate_hz",
            10.0,
        )
        self.declare_parameter(
            "joint_tolerance_rad",
            0.025,
        )
        self.declare_parameter(
            "stable_samples",
            8,
        )

        self.declare_parameter(
            "ready_sentinel",
            "/tmp/piper_pick_handover_work_home_ready",
        )

        self.joint_names = list(
            self.get_parameter(
                "joint_names"
            ).value
        )
        self.work_home = [
            float(v)
            for v in self.get_parameter(
                "work_home_positions"
            ).value
        ]

        self.feedback_topic = str(
            self.get_parameter(
                "feedback_topic"
            ).value
        )
        self.control_topic = str(
            self.get_parameter(
                "control_topic"
            ).value
        )
        self.control_gate_service = str(
            self.get_parameter(
                "control_gate_service"
            ).value
        )

        self.feedback_wait_timeout = float(
            self.get_parameter(
                "feedback_wait_timeout_sec"
            ).value
        )
        self.move_timeout = float(
            self.get_parameter(
                "move_timeout_sec"
            ).value
        )
        self.command_rate_hz = float(
            self.get_parameter(
                "command_rate_hz"
            ).value
        )
        self.tolerance = float(
            self.get_parameter(
                "joint_tolerance_rad"
            ).value
        )
        self.stable_samples = int(
            self.get_parameter(
                "stable_samples"
            ).value
        )

        self.ready_sentinel = Path(
            str(
                self.get_parameter(
                    "ready_sentinel"
                ).value
            )
        )

        if (
            len(self.joint_names) != 6
            or len(self.work_home) != 6
        ):
            raise ValueError(
                "WORK_HOME must contain exactly 6 arm joints."
            )

        self.current = {}

        self.create_subscription(
            JointState,
            self.feedback_topic,
            self._feedback_cb,
            20,
            callback_group=self.cb_group,
        )

        self.command_pub = self.create_publisher(
            JointState,
            self.control_topic,
            10,
        )

        self.gate_client = self.create_client(
            SetBool,
            self.control_gate_service,
            callback_group=self.cb_group,
        )

        self.ready_pub = self.create_publisher(
            Bool,
            "/work_home/startup_reached",
            1,
        )

        try:
            self.ready_sentinel.unlink(
                missing_ok=True
            )
        except Exception:
            pass

        self.worker = threading.Thread(
            target=self._run_startup_sequence,
            daemon=True,
        )
        self.worker.start()

        self.get_logger().warning(
            "STARTUP AUTO-MOTION ENABLED: robot will move to WORK_HOME."
        )
        self.get_logger().info(
            "WORK_HOME = "
            + self._format_vector(
                self.work_home
            )
        )

    @staticmethod
    def _format_vector(values):
        return "[" + ", ".join(
            f"{float(v):+.6f}"
            for v in values
        ) + "] rad"

    def _feedback_cb(self, msg):
        with self.feedback_lock:
            for idx, name in enumerate(
                msg.name
            ):
                if idx < len(msg.position):
                    self.current[
                        str(name)
                    ] = float(
                        msg.position[idx]
                    )

    def _current_arm(self):
        with self.feedback_lock:
            result = []

            for name in self.joint_names:
                if name not in self.current:
                    return None

                result.append(
                    self.current[name]
                )

            return result

    @staticmethod
    def _wait_future(
        future,
        timeout_sec,
    ):
        event = threading.Event()

        future.add_done_callback(
            lambda _future: event.set()
        )

        if not event.wait(
            max(
                0.05,
                float(timeout_sec),
            )
        ):
            return None

        try:
            return future.result()
        except Exception:
            return None

    def _set_gate(
        self,
        enabled,
    ):
        if not self.gate_client.wait_for_service(
            timeout_sec=5.0
        ):
            return (
                False,
                f"service unavailable: {self.control_gate_service}",
            )

        req = SetBool.Request()
        req.data = bool(
            enabled
        )

        result = self._wait_future(
            self.gate_client.call_async(
                req
            ),
            5.0,
        )

        if result is None:
            return (
                False,
                "control gate call timed out",
            )

        return (
            bool(result.success),
            str(result.message),
        )

    def _publish_work_home(self):
        msg = JointState()

        msg.header.stamp = (
            self.get_clock().now().to_msg()
        )
        msg.name = list(
            self.joint_names
        )
        msg.position = list(
            self.work_home
        )

        # Do not include the gripper.
        msg.velocity = []
        msg.effort = []

        self.command_pub.publish(
            msg
        )

    def _max_error(self):
        current = self._current_arm()

        if current is None:
            return (
                None,
                None,
            )

        errors = [
            abs(
                float(now)
                - float(target)
            )
            for now, target in zip(
                current,
                self.work_home,
            )
        ]

        return (
            max(errors),
            current,
        )

    def _fail_and_hold(self, message):
        # Important: DO NOT exit on failure.
        # The launch file starts MoveIt only when this process exits
        # after creating the success sentinel.
        self.get_logger().error(
            "WORK_HOME STARTUP FAILED: "
            + message
        )
        self.get_logger().error(
            "MoveIt will NOT be started automatically. "
            "Fix the problem and restart the bringup launch."
        )

        ready = Bool()
        ready.data = False
        self.ready_pub.publish(
            ready
        )

    def _run_startup_sequence(self):
        # ----------------------------------------------------------
        # Wait for actual arm feedback.
        # ----------------------------------------------------------
        start = time.monotonic()

        while (
            rclpy.ok()
            and
            time.monotonic() - start
            < self.feedback_wait_timeout
        ):
            if self._current_arm() is not None:
                break

            time.sleep(0.05)

        if self._current_arm() is None:
            self._fail_and_hold(
                "joint1~joint6 feedback did not arrive."
            )
            return

        # ----------------------------------------------------------
        # Explicitly open gate for pre-MoveIt direct startup motion.
        # ----------------------------------------------------------
        gate_ok, gate_msg = self._set_gate(
            True
        )

        if not gate_ok:
            self._fail_and_hold(
                "cannot OPEN /control_enable: "
                + gate_msg
            )
            return

        self.get_logger().warning(
            "Control gate OPEN for startup WORK_HOME motion."
        )

        # ----------------------------------------------------------
        # Command WORK_HOME until stable.
        # ----------------------------------------------------------
        period = 1.0 / max(
            1.0,
            self.command_rate_hz,
        )

        stable = 0
        move_start = time.monotonic()

        while (
            rclpy.ok()
            and
            time.monotonic() - move_start
            < self.move_timeout
        ):
            self._publish_work_home()

            error, current = (
                self._max_error()
            )

            if error is not None:
                if error <= self.tolerance:
                    stable += 1
                else:
                    stable = 0

                if stable >= self.stable_samples:
                    self.get_logger().info(
                        "WORK_HOME REACHED | "
                        f"max_joint_error={error:.6f} rad | "
                        "feedback="
                        + self._format_vector(
                            current
                        )
                    )
                    break

            time.sleep(
                period
            )

        else:
            self._set_gate(
                False
            )
            self._fail_and_hold(
                "timeout while moving to WORK_HOME."
            )
            return

        # ----------------------------------------------------------
        # Close gate BEFORE MoveIt starts.
        # ----------------------------------------------------------
        gate_ok, gate_msg = self._set_gate(
            False
        )

        if not gate_ok:
            self._fail_and_hold(
                "WORK_HOME reached, but cannot CLOSE gate: "
                + gate_msg
            )
            return

        self.get_logger().info(
            "Control gate CLOSED. MoveIt may now start safely."
        )

        # Success marker used by launch event handler.
        try:
            self.ready_sentinel.write_text(
                "WORK_HOME_READY\n",
                encoding="utf-8",
            )
        except Exception as exc:
            self._fail_and_hold(
                f"cannot create ready sentinel: {exc}"
            )
            return

        ready = Bool()
        ready.data = True
        self.ready_pub.publish(
            ready
        )

        time.sleep(0.25)

        # Only SUCCESS exits. OnProcessExit will then start MoveIt.
        rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)

    node = WorkHomeStartupNode()

    executor = MultiThreadedExecutor(
        num_threads=3
    )
    executor.add_node(node)

    try:
        executor.spin()

    except KeyboardInterrupt:
        pass

    finally:
        executor.shutdown()
        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
