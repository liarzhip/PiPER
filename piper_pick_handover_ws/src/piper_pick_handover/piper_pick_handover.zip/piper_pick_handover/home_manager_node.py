import json
import math
import os
import threading
import time
from pathlib import Path

import rclpy

from moveit_msgs.action import ExecuteTrajectory, MoveGroup
from moveit_msgs.msg import (
    Constraints,
    DisplayTrajectory,
    JointConstraint,
    MoveItErrorCodes,
)
from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import (
    DurabilityPolicy,
    HistoryPolicy,
    QoSProfile,
    ReliabilityPolicy,
)
from sensor_msgs.msg import JointState
from std_msgs.msg import Bool
from std_srvs.srv import Trigger


class HomeManagerNode(Node):
    """
    Project logical HOME manager.

    HOME is NOT a hardware encoder-zero calibration.

    It stores only:
        joint1 ... joint6

    The gripper is intentionally excluded and is controlled separately
    through the MoveIt "gripper" group.

    Services:
        /home/capture
            Capture CURRENT real joint1..joint6 feedback and persist it.

        /home/reload
            Reload persisted HOME (or configured fallback).

        /home/plan
            Plan CURRENT -> HOME through MoveIt. No physical execution.

        /home/execute
            Fresh-plan CURRENT -> HOME and execute it through MoveIt.
            Gated by allow_home_execute.

    Topics:
        /home/ready
        /home/joint_states
    """

    def __init__(self):
        super().__init__("home_manager_node")

        self.cb_group = ReentrantCallbackGroup()
        self.operation_lock = threading.Lock()
        self.feedback_lock = threading.Lock()

        # ==========================================================
        # Parameters
        # ==========================================================

        self.declare_parameter(
            "planning_group",
            "arm",
        )
        self.declare_parameter(
            "move_group_action",
            "/move_action",
        )
        self.declare_parameter(
            "execute_action",
            "/execute_trajectory",
        )

        self.declare_parameter(
            "joint_names",
            [
                "joint1",
                "joint2",
                "joint3",
                "joint4",
                "joint5",
                "joint6",
            ],
        )

        # Fallback logical HOME.
        self.declare_parameter(
            "configured_home_joint_positions",
            [
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
            ],
        )

        # Persist captured HOME outside the install tree.
        self.declare_parameter(
            "home_file",
            "~/.ros/piper_pick_handover/home.json",
        )
        self.declare_parameter(
            "load_saved_home_on_startup",
            True,
        )

        self.declare_parameter(
            "allowed_planning_time",
            5.0,
        )
        self.declare_parameter(
            "num_planning_attempts",
            5,
        )
        self.declare_parameter(
            "velocity_scaling",
            0.08,
        )
        self.declare_parameter(
            "acceleration_scaling",
            0.05,
        )
        self.declare_parameter(
            "joint_goal_tolerance_rad",
            0.015,
        )
        self.declare_parameter(
            "post_execute_joint_tolerance_rad",
            0.030,
        )

        self.declare_parameter(
            "action_server_timeout_sec",
            5.0,
        )
        self.declare_parameter(
            "plan_result_timeout_sec",
            20.0,
        )
        self.declare_parameter(
            "execute_result_timeout_sec",
            60.0,
        )
        self.declare_parameter(
            "feedback_wait_timeout_sec",
            2.0,
        )

        # Safety gate. Start PLAN-ONLY.
        self.declare_parameter(
            "allow_home_execute",
            False,
        )

        # ==========================================================
        # Read parameters
        # ==========================================================

        self.planning_group = str(
            self.get_parameter(
                "planning_group"
            ).value
        )
        self.move_group_action = str(
            self.get_parameter(
                "move_group_action"
            ).value
        )
        self.execute_action = str(
            self.get_parameter(
                "execute_action"
            ).value
        )

        self.joint_names = list(
            self.get_parameter(
                "joint_names"
            ).value
        )

        self.configured_home = [
            float(x)
            for x in self.get_parameter(
                "configured_home_joint_positions"
            ).value
        ]

        self.home_file = Path(
            os.path.expanduser(
                str(
                    self.get_parameter(
                        "home_file"
                    ).value
                )
            )
        )

        self.load_saved_home_on_startup = bool(
            self.get_parameter(
                "load_saved_home_on_startup"
            ).value
        )

        self.allowed_planning_time = float(
            self.get_parameter(
                "allowed_planning_time"
            ).value
        )
        self.num_planning_attempts = int(
            self.get_parameter(
                "num_planning_attempts"
            ).value
        )
        self.velocity_scaling = float(
            self.get_parameter(
                "velocity_scaling"
            ).value
        )
        self.acceleration_scaling = float(
            self.get_parameter(
                "acceleration_scaling"
            ).value
        )
        self.goal_tolerance = float(
            self.get_parameter(
                "joint_goal_tolerance_rad"
            ).value
        )
        self.post_execute_tolerance = float(
            self.get_parameter(
                "post_execute_joint_tolerance_rad"
            ).value
        )

        self.action_server_timeout = float(
            self.get_parameter(
                "action_server_timeout_sec"
            ).value
        )
        self.plan_result_timeout = float(
            self.get_parameter(
                "plan_result_timeout_sec"
            ).value
        )
        self.execute_result_timeout = float(
            self.get_parameter(
                "execute_result_timeout_sec"
            ).value
        )
        self.feedback_wait_timeout = float(
            self.get_parameter(
                "feedback_wait_timeout_sec"
            ).value
        )

        self.allow_home_execute = bool(
            self.get_parameter(
                "allow_home_execute"
            ).value
        )

        if (
            len(self.joint_names) != 6
            or len(self.configured_home) != 6
        ):
            raise ValueError(
                "HOME must contain exactly joint1~joint6."
            )

        if len(set(self.joint_names)) != 6:
            raise ValueError(
                "joint_names contains duplicates."
            )

        # ==========================================================
        # State
        # ==========================================================

        self.current_joint_map = {}
        self.home_positions = None
        self.home_source = "none"

        latched_qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
        )

        self.create_subscription(
            JointState,
            "/feedback/joint_states",
            self._feedback_cb,
            20,
            callback_group=self.cb_group,
        )

        self.home_ready_pub = self.create_publisher(
            Bool,
            "/home/ready",
            latched_qos,
        )

        self.home_joint_pub = self.create_publisher(
            JointState,
            "/home/joint_states",
            latched_qos,
        )

        self.display_pub = self.create_publisher(
            DisplayTrajectory,
            "/display_planned_path",
            10,
        )

        self.move_group_client = ActionClient(
            self,
            MoveGroup,
            self.move_group_action,
            callback_group=self.cb_group,
        )

        self.execute_client = ActionClient(
            self,
            ExecuteTrajectory,
            self.execute_action,
            callback_group=self.cb_group,
        )

        self.create_service(
            Trigger,
            "/home/capture",
            self._capture_cb,
            callback_group=self.cb_group,
        )

        self.create_service(
            Trigger,
            "/home/reload",
            self._reload_cb,
            callback_group=self.cb_group,
        )

        self.create_service(
            Trigger,
            "/home/plan",
            self._plan_cb,
            callback_group=self.cb_group,
        )

        self.create_service(
            Trigger,
            "/home/execute",
            self._execute_cb,
            callback_group=self.cb_group,
        )

        # Load persisted HOME if available, otherwise use configured HOME.
        self._load_home_at_startup()

        self.get_logger().info(
            "HOME manager started."
        )
        self.get_logger().info(
            "Logical HOME only; hardware encoder zero is NOT modified."
        )
        self.get_logger().info(
            f"HOME source = {self.home_source}"
        )
        self.get_logger().info(
            "HOME joints = "
            + self._format_joint_vector(
                self.home_positions
            )
        )

        if not self.allow_home_execute:
            self.get_logger().warning(
                "HOME execution BLOCKED "
                "(allow_home_execute=false). "
                "Use /home/plan first."
            )

    # ==============================================================
    # Feedback / state
    # ==============================================================

    def _feedback_cb(
        self,
        msg,
    ):
        with self.feedback_lock:
            for index, name in enumerate(
                msg.name
            ):
                if index < len(msg.position):
                    self.current_joint_map[
                        str(name)
                    ] = float(
                        msg.position[index]
                    )

    def _current_arm_positions(
        self,
    ):
        with self.feedback_lock:
            values = []

            for name in self.joint_names:
                if name not in self.current_joint_map:
                    return None

                values.append(
                    float(
                        self.current_joint_map[
                            name
                        ]
                    )
                )

            return values

    def _publish_home(
        self,
    ):
        ready = Bool()
        ready.data = (
            self.home_positions is not None
        )
        self.home_ready_pub.publish(
            ready
        )

        if self.home_positions is None:
            return

        msg = JointState()
        msg.header.stamp = (
            self.get_clock().now().to_msg()
        )
        msg.name = list(
            self.joint_names
        )
        msg.position = list(
            self.home_positions
        )

        self.home_joint_pub.publish(
            msg
        )

    @staticmethod
    def _format_joint_vector(
        values,
    ):
        if values is None:
            return "None"

        return "[" + ", ".join(
            f"{float(x):+.5f}"
            for x in values
        ) + "] rad"

    # ==============================================================
    # Persistence
    # ==============================================================

    def _save_home(
        self,
        values,
    ):
        self.home_file.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        data = {
            "joint_names": list(
                self.joint_names
            ),
            "joint_positions": [
                float(x)
                for x in values
            ],
        }

        tmp = self.home_file.with_suffix(
            ".json.tmp"
        )

        tmp.write_text(
            json.dumps(
                data,
                indent=2,
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )

        tmp.replace(
            self.home_file
        )

    def _load_saved_home(
        self,
    ):
        if not self.home_file.exists():
            return None

        data = json.loads(
            self.home_file.read_text(
                encoding="utf-8"
            )
        )

        names = list(
            data.get(
                "joint_names",
                [],
            )
        )

        positions = [
            float(x)
            for x in data.get(
                "joint_positions",
                [],
            )
        ]

        if names != self.joint_names:
            raise RuntimeError(
                "Saved HOME joint_names mismatch: "
                f"{names}"
            )

        if len(positions) != 6:
            raise RuntimeError(
                "Saved HOME does not contain 6 positions."
            )

        return positions

    def _load_home_at_startup(
        self,
    ):
        if self.load_saved_home_on_startup:
            try:
                saved = self._load_saved_home()

                if saved is not None:
                    self.home_positions = saved
                    self.home_source = "saved_file"
                    self._publish_home()
                    return

            except Exception as exc:
                self.get_logger().warning(
                    "Failed to load saved HOME; "
                    f"using configured fallback: {exc}"
                )

        self.home_positions = list(
            self.configured_home
        )
        self.home_source = "configured_fallback"
        self._publish_home()

    # ==============================================================
    # Futures
    # ==============================================================

    @staticmethod
    def _wait_future(
        future,
        timeout_sec,
    ):
        event = threading.Event()

        future.add_done_callback(
            lambda _future: event.set()
        )

        if not event.wait(
            timeout=max(
                0.05,
                float(timeout_sec),
            )
        ):
            return None

        try:
            return future.result()
        except Exception:
            return None

    # ==============================================================
    # HOME capture / reload
    # ==============================================================

    def _capture_cb(
        self,
        request,
        response,
    ):
        del request

        current = self._current_arm_positions()

        if current is None:
            response.success = False
            response.message = (
                "Cannot capture HOME: "
                "joint1~joint6 feedback is incomplete."
            )
            return response

        try:
            self._save_home(
                current
            )
        except Exception as exc:
            response.success = False
            response.message = (
                "Failed to persist HOME: "
                f"{exc}"
            )
            return response

        self.home_positions = list(
            current
        )
        self.home_source = "captured_current_feedback"
        self._publish_home()

        response.success = True
        response.message = (
            "HOME CAPTURED | "
            + self._format_joint_vector(
                current
            )
            + f" | saved={self.home_file}"
        )

        self.get_logger().info(
            response.message
        )

        return response

    def _reload_cb(
        self,
        request,
        response,
    ):
        del request

        try:
            saved = self._load_saved_home()
        except Exception as exc:
            response.success = False
            response.message = (
                f"Failed to reload HOME: {exc}"
            )
            return response

        if saved is None:
            self.home_positions = list(
                self.configured_home
            )
            self.home_source = "configured_fallback"
            source = (
                "no saved file; configured fallback loaded"
            )
        else:
            self.home_positions = saved
            self.home_source = "saved_file"
            source = (
                f"saved file loaded: {self.home_file}"
            )

        self._publish_home()

        response.success = True
        response.message = (
            "HOME RELOADED | "
            + source
            + " | "
            + self._format_joint_vector(
                self.home_positions
            )
        )

        return response

    # ==============================================================
    # MoveIt HOME planning
    # ==============================================================

    def _build_home_goal(
        self,
    ):
        if self.home_positions is None:
            raise RuntimeError(
                "HOME is not available."
            )

        goal = MoveGroup.Goal()
        req = goal.request

        req.group_name = (
            self.planning_group
        )
        req.num_planning_attempts = max(
            1,
            self.num_planning_attempts,
        )
        req.allowed_planning_time = (
            self.allowed_planning_time
        )

        req.max_velocity_scaling_factor = (
            self.velocity_scaling
        )
        req.max_acceleration_scaling_factor = (
            self.acceleration_scaling
        )

        # Use MoveIt's monitored CURRENT real state.
        req.start_state.is_diff = True

        constraints = Constraints()

        for name, position in zip(
            self.joint_names,
            self.home_positions,
        ):
            jc = JointConstraint()
            jc.joint_name = str(
                name
            )
            jc.position = float(
                position
            )
            jc.tolerance_above = (
                self.goal_tolerance
            )
            jc.tolerance_below = (
                self.goal_tolerance
            )
            jc.weight = 1.0

            constraints.joint_constraints.append(
                jc
            )

        req.goal_constraints = [
            constraints
        ]

        options = goal.planning_options
        options.plan_only = True
        options.look_around = False
        options.replan = False

        return goal

    def _plan_home_internal(
        self,
    ):
        if not self.move_group_client.wait_for_server(
            timeout_sec=self.action_server_timeout
        ):
            return (
                False,
                "MoveGroup action unavailable.",
                None,
            )

        try:
            goal = self._build_home_goal()
        except Exception as exc:
            return (
                False,
                str(exc),
                None,
            )

        self.get_logger().info(
            "Planning CURRENT -> HOME | "
            + self._format_joint_vector(
                self.home_positions
            )
        )

        send_future = (
            self.move_group_client.send_goal_async(
                goal
            )
        )

        goal_handle = self._wait_future(
            send_future,
            self.action_server_timeout,
        )

        if (
            goal_handle is None
            or
            not goal_handle.accepted
        ):
            return (
                False,
                "MoveGroup rejected HOME goal.",
                None,
            )

        result_future = (
            goal_handle.get_result_async()
        )

        wrapped = self._wait_future(
            result_future,
            self.plan_result_timeout,
        )

        if wrapped is None:
            return (
                False,
                "HOME planning timed out.",
                None,
            )

        result = wrapped.result

        error_code = int(
            result.error_code.val
        )

        if error_code != MoveItErrorCodes.SUCCESS:
            return (
                False,
                "HOME planning failed; "
                f"MoveIt error_code={error_code}.",
                None,
            )

        trajectory = (
            result.planned_trajectory
        )

        points = list(
            trajectory
            .joint_trajectory
            .points
        )

        if len(points) == 0:
            return (
                False,
                "HOME trajectory contains no points.",
                None,
            )

        # Explicitly verify that this is an ARM trajectory,
        # not a gripper trajectory.
        trajectory_joints = list(
            trajectory
            .joint_trajectory
            .joint_names
        )

        missing = [
            name
            for name in self.joint_names
            if name not in trajectory_joints
        ]

        if missing:
            return (
                False,
                "HOME trajectory is missing arm joints: "
                f"{missing}; trajectory_joints={trajectory_joints}",
                None,
            )

        display = DisplayTrajectory()
        display.trajectory_start = (
            result.trajectory_start
        )
        display.trajectory = [
            trajectory
        ]

        self.display_pub.publish(
            display
        )

        return (
            True,
            (
                "HOME PLAN OK | "
                f"points={len(points)} | "
                f"joints={trajectory_joints}"
            ),
            trajectory,
        )

    # ==============================================================
    # Execute / verification
    # ==============================================================

    def _execute_trajectory(
        self,
        trajectory,
    ):
        if not self.execute_client.wait_for_server(
            timeout_sec=self.action_server_timeout
        ):
            return (
                False,
                "ExecuteTrajectory action unavailable.",
            )

        goal = ExecuteTrajectory.Goal()
        goal.trajectory = trajectory

        send_future = (
            self.execute_client.send_goal_async(
                goal
            )
        )

        goal_handle = self._wait_future(
            send_future,
            self.action_server_timeout,
        )

        if (
            goal_handle is None
            or
            not goal_handle.accepted
        ):
            return (
                False,
                "ExecuteTrajectory rejected HOME trajectory.",
            )

        result_future = (
            goal_handle.get_result_async()
        )

        wrapped = self._wait_future(
            result_future,
            self.execute_result_timeout,
        )

        if wrapped is None:
            return (
                False,
                "HOME execution timed out.",
            )

        result = wrapped.result
        error_code = int(
            result.error_code.val
        )

        if error_code != MoveItErrorCodes.SUCCESS:
            return (
                False,
                "HOME execution failed; "
                f"MoveIt error_code={error_code}.",
            )

        return (
            True,
            "HOME trajectory execution succeeded.",
        )

    def _verify_home(
        self,
    ):
        deadline = (
            time.monotonic()
            + self.feedback_wait_timeout
        )

        last_current = None

        while (
            rclpy.ok()
            and time.monotonic() < deadline
        ):
            current = self._current_arm_positions()

            if current is not None:
                last_current = current

                errors = [
                    abs(
                        float(now)
                        - float(target)
                    )
                    for now, target in zip(
                        current,
                        self.home_positions,
                    )
                ]

                if max(errors) <= self.post_execute_tolerance:
                    return (
                        True,
                        (
                            "HOME VERIFIED | max_joint_error="
                            f"{max(errors):.5f} rad "
                            f"({math.degrees(max(errors)):.2f} deg)"
                        ),
                    )

            time.sleep(0.05)

        if last_current is None:
            return (
                False,
                "HOME verification failed: no complete joint feedback.",
            )

        errors = [
            abs(
                float(now)
                - float(target)
            )
            for now, target in zip(
                last_current,
                self.home_positions,
            )
        ]

        return (
            False,
            (
                "HOME verification failed | "
                f"max_joint_error={max(errors):.5f} rad "
                f"({math.degrees(max(errors)):.2f} deg)"
            ),
        )

    # ==============================================================
    # Services
    # ==============================================================

    def _plan_cb(
        self,
        request,
        response,
    ):
        del request

        if not self.operation_lock.acquire(
            blocking=False
        ):
            response.success = False
            response.message = (
                "HOME operation already in progress."
            )
            return response

        try:
            (
                ok,
                message,
                trajectory,
            ) = self._plan_home_internal()

            response.success = bool(
                ok
            )
            response.message = message

            if ok:
                self.get_logger().info(
                    message
                )
            else:
                self.get_logger().error(
                    message
                )

            return response

        finally:
            self.operation_lock.release()

    def _execute_cb(
        self,
        request,
        response,
    ):
        del request

        if not self.allow_home_execute:
            response.success = False
            response.message = (
                "HOME execution blocked: "
                "allow_home_execute=false."
            )
            return response

        if not self.operation_lock.acquire(
            blocking=False
        ):
            response.success = False
            response.message = (
                "HOME operation already in progress."
            )
            return response

        try:
            # Always fresh-plan from CURRENT real robot state.
            (
                plan_ok,
                plan_message,
                trajectory,
            ) = self._plan_home_internal()

            if not plan_ok:
                response.success = False
                response.message = (
                    "HOME fresh planning failed: "
                    + plan_message
                )
                return response

            self.get_logger().warning(
                "EXECUTING REAL ROBOT -> LOGICAL HOME"
            )

            (
                execute_ok,
                execute_message,
            ) = self._execute_trajectory(
                trajectory
            )

            if not execute_ok:
                response.success = False
                response.message = (
                    execute_message
                )
                return response

            (
                verify_ok,
                verify_message,
            ) = self._verify_home()

            response.success = bool(
                verify_ok
            )
            response.message = (
                verify_message
                if verify_ok
                else (
                    "Trajectory completed, but "
                    + verify_message
                )
            )

            if verify_ok:
                self.get_logger().info(
                    response.message
                )
            else:
                self.get_logger().error(
                    response.message
                )

            return response

        finally:
            self.operation_lock.release()


def main(args=None):
    rclpy.init(args=args)

    node = HomeManagerNode()

    executor = MultiThreadedExecutor(
        num_threads=4
    )
    executor.add_node(node)

    try:
        executor.spin()

    except KeyboardInterrupt:
        pass

    finally:
        executor.shutdown()
        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
