import threading
import time

import rclpy

from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_srvs.srv import Trigger


class GripperNode(Node):
    """
    AgileX parallel gripper control for PIPER-X.

    Official agx_arm_ros interface:
        command:  /control/joint_states  (sensor_msgs/JointState)
        feedback: /feedback/joint_states (sensor_msgs/JointState)

    Externally exposed gripper joint:
        name = "gripper"
        position = total opening width [m], range [0.0, 0.1]
        effort = target force [N], range [0.5, 3.0]

    STEP 7C uses ONLY /gripper/open.
    /gripper/close is implemented for later steps but should not be used yet.
    """

    def __init__(self):
        super().__init__("gripper_node")

        self.cb_group = ReentrantCallbackGroup()

        self.declare_parameter(
            "control_topic",
            "/control/joint_states",
        )
        self.declare_parameter(
            "feedback_topic",
            "/feedback/joint_states",
        )

        self.declare_parameter(
            "gripper_joint_name",
            "gripper",
        )

        # Keep some margin from the 0.10 m hard maximum.
        self.declare_parameter(
            "open_width_m",
            0.090,
        )

        # Placeholder for a later verified grasp width.
        self.declare_parameter(
            "close_width_m",
            0.020,
        )

        self.declare_parameter(
            "command_force_n",
            1.0,
        )

        self.declare_parameter(
            "position_tolerance_m",
            0.006,
        )
        self.declare_parameter(
            "command_timeout_sec",
            4.0,
        )
        self.declare_parameter(
            "command_publish_hz",
            10.0,
        )

        self.control_topic = str(
            self.get_parameter("control_topic").value
        )
        self.feedback_topic = str(
            self.get_parameter("feedback_topic").value
        )
        self.gripper_joint_name = str(
            self.get_parameter("gripper_joint_name").value
        )

        self.open_width = float(
            self.get_parameter("open_width_m").value
        )
        self.close_width = float(
            self.get_parameter("close_width_m").value
        )
        self.force = float(
            self.get_parameter("command_force_n").value
        )

        self.position_tolerance = float(
            self.get_parameter("position_tolerance_m").value
        )
        self.command_timeout = float(
            self.get_parameter("command_timeout_sec").value
        )
        self.command_publish_hz = float(
            self.get_parameter("command_publish_hz").value
        )

        if not (0.0 <= self.open_width <= 0.1):
            raise ValueError(
                "open_width_m must be within [0.0, 0.1]"
            )

        if not (0.0 <= self.close_width <= 0.1):
            raise ValueError(
                "close_width_m must be within [0.0, 0.1]"
            )

        if not (0.5 <= self.force <= 3.0):
            raise ValueError(
                "command_force_n must be within [0.5, 3.0]"
            )

        self.command_pub = self.create_publisher(
            JointState,
            self.control_topic,
            10,
        )

        self.feedback_sub = self.create_subscription(
            JointState,
            self.feedback_topic,
            self.feedback_callback,
            20,
            callback_group=self.cb_group,
        )

        self.current_width = None
        self.feedback_lock = threading.Lock()
        self.operation_lock = threading.Lock()

        self.create_service(
            Trigger,
            "/gripper/open",
            self.open_callback,
            callback_group=self.cb_group,
        )

        self.create_service(
            Trigger,
            "/gripper/close",
            self.close_callback,
            callback_group=self.cb_group,
        )

        self.get_logger().info(
            "AgileX gripper node started."
        )
        self.get_logger().info(
            f"Open width = {self.open_width:.3f} m"
        )
        self.get_logger().warning(
            "STEP 7C: use /gripper/open only. "
            "Do NOT call /gripper/close yet."
        )

    def feedback_callback(self, msg):
        try:
            index = list(
                msg.name
            ).index(
                self.gripper_joint_name
            )
        except ValueError:
            return

        if index >= len(msg.position):
            return

        with self.feedback_lock:
            self.current_width = float(
                msg.position[index]
            )

    def get_current_width(self):
        with self.feedback_lock:
            return self.current_width

    def publish_command(
        self,
        width,
    ):
        msg = JointState()

        msg.header.stamp = (
            self.get_clock().now().to_msg()
        )

        msg.name = [
            self.gripper_joint_name
        ]
        msg.position = [
            float(width)
        ]
        msg.velocity = []
        msg.effort = [
            float(self.force)
        ]

        self.command_pub.publish(
            msg
        )

    def command_and_verify(
        self,
        target_width,
    ):
        deadline = (
            time.monotonic()
            + self.command_timeout
        )

        period = (
            1.0
            / max(
                1.0,
                self.command_publish_hz,
            )
        )

        while (
            rclpy.ok()
            and
            time.monotonic() < deadline
        ):
            self.publish_command(
                target_width
            )

            current = self.get_current_width()

            if current is not None:
                error = abs(
                    current
                    - target_width
                )

                if error <= self.position_tolerance:
                    return (
                        True,
                        (
                            f"target={target_width:.3f} m, "
                            f"feedback={current:.3f} m, "
                            f"error={error * 1000.0:.1f} mm"
                        ),
                    )

            time.sleep(
                period
            )

        current = self.get_current_width()

        if current is None:
            return (
                False,
                "No 'gripper' feedback found in /feedback/joint_states.",
            )

        return (
            False,
            (
                f"Gripper did not reach target within timeout: "
                f"target={target_width:.3f} m, "
                f"feedback={current:.3f} m."
            ),
        )

    def open_callback(
        self,
        request,
        response,
    ):
        del request

        if not self.operation_lock.acquire(
            blocking=False
        ):
            response.success = False
            response.message = (
                "Gripper operation already in progress."
            )
            return response

        try:
            (
                ok,
                detail,
            ) = self.command_and_verify(
                self.open_width
            )

            response.success = bool(
                ok
            )
            response.message = (
                "GRIPPER OPEN OK | "
                + detail
                if ok
                else "GRIPPER OPEN FAILED | "
                + detail
            )

            if ok:
                self.get_logger().info(
                    response.message
                )
            else:
                self.get_logger().error(
                    response.message
                )

            return response

        finally:
            self.operation_lock.release()

    def close_callback(
        self,
        request,
        response,
    ):
        del request

        if not self.operation_lock.acquire(
            blocking=False
        ):
            response.success = False
            response.message = (
                "Gripper operation already in progress."
            )
            return response

        try:
            (
                ok,
                detail,
            ) = self.command_and_verify(
                self.close_width
            )

            response.success = bool(
                ok
            )
            response.message = (
                "GRIPPER CLOSE OK | "
                + detail
                if ok
                else "GRIPPER CLOSE FAILED | "
                + detail
            )

            if ok:
                self.get_logger().info(
                    response.message
                )
            else:
                self.get_logger().error(
                    response.message
                )

            return response

        finally:
            self.operation_lock.release()


def main(args=None):
    rclpy.init(args=args)

    node = GripperNode()

    executor = MultiThreadedExecutor(
        num_threads=3
    )
    executor.add_node(node)

    try:
        executor.spin()

    except KeyboardInterrupt:
        pass

    finally:
        executor.shutdown()
        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
