#!/usr/bin/env python3
"""
PiPER Pick & Handover Manager V3

Three terminal architecture:

1. Piper driver
2. Vision pipeline
3. Manager

Task sequence:

INIT
 -> MOVE_WORK_HOME
 -> WAIT_SCENE
 -> CREATE_TABLE_SCENE
 -> PLAN_GRASP
 -> EXECUTE_GRASP
 -> CLOSE_GRIPPER
 -> VERIFY_GRASP
 -> LIFT
 -> WAIT_HAND
 -> COMPUTE_HANDOVER
 -> EXECUTE_HANDOVER
 -> OPEN_GRIPPER
 -> RETREAT
 -> RETURN_WORK_HOME
 -> DONE

The manager only coordinates tasks.
Hardware and perception remain independent.
"""

import enum
import rclpy

from rclpy.node import Node
from std_srvs.srv import Trigger
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Bool


class State(enum.Enum):
    IDLE = 0
    MOVE_WORK_HOME = 1
    WAIT_SCENE = 2
    CREATE_TABLE_SCENE = 3
    PLAN_GRASP = 4
    EXECUTE_GRASP = 5
    CLOSE_GRIPPER = 6
    VERIFY_GRASP = 7
    LIFT = 8
    WAIT_HAND = 9
    COMPUTE_HANDOVER = 10
    EXECUTE_HANDOVER = 11
    OPEN_GRIPPER = 12
    RETREAT = 13
    RETURN_WORK_HOME = 14


class PiperManager(Node):

    def __init__(self):
        super().__init__("piper_manager_node")

        self.state = State.IDLE
        self.running = False

        self.object_ready = False
        self.hand_ready = False

        self.object_pose = None
        self.palm_pose = None

        self.action_clients = {}

        # perception
        self.create_subscription(
            PoseStamped,
            "/targets/object_pose_base",
            self.object_pose_cb,
            10
        )

        self.create_subscription(
            PoseStamped,
            "/targets/palm_pose_base",
            self.palm_pose_cb,
            10
        )

        self.create_subscription(
            Bool,
            "/scene/object_ready",
            self.object_ready_cb,
            10
        )

        self.create_subscription(
            Bool,
            "/scene/hand_ready",
            self.hand_ready_cb,
            10
        )

        # action interfaces
        actions = [
            "go_work_home",
            "create_table_scene",
            "plan_grasp",
            "execute_grasp",
            "gripper_close",
            "verify_grasp",
            "lift",
            "compute_handover",
            "execute_handover",
            "gripper_open",
            "retreat",
            "return_work_home"
        ]

        for action in actions:
            self.action_clients[action] = self.create_client(
                Trigger,
                "/robot/" + action
            )

        self.create_service(
            Trigger,
            "/manager/start",
            self.start_cb
        )

        self.timer = self.create_timer(
            0.2,
            self.loop
        )

        self.get_logger().info(
            "PiPER Manager V3 ready"
        )


    def object_pose_cb(self, msg):
        self.object_pose = msg


    def palm_pose_cb(self, msg):
        self.palm_pose = msg


    def object_ready_cb(self, msg):
        self.object_ready = msg.data


    def hand_ready_cb(self, msg):
        self.hand_ready = msg.data


    def start_cb(self, request, response):
        if self.running:
            response.success = False
            response.message = "Task running"
            return response

        self.running = True
        self.state = State.MOVE_WORK_HOME

        response.success = True
        response.message = "Task started"

        self.get_logger().info(
            "TASK START"
        )

        return response


    def call_action(self, name):

        client = self.action_clients[name]

        if not client.wait_for_service(2.0):
            self.get_logger().error(
                name + " unavailable"
            )
            return False

        future = client.call_async(
            Trigger.Request()
        )

        rclpy.spin_until_future_complete(
            self,
            future
        )

        result = future.result()

        if result:
            self.get_logger().info(
                name + ": " + result.message
            )
            return result.success

        return False


    def loop(self):

        if not self.running:
            return

        if self.state == State.MOVE_WORK_HOME:

            if self.call_action("go_work_home"):
                self.state = State.WAIT_SCENE


        elif self.state == State.WAIT_SCENE:

            if self.object_pose is not None:
                self.state = State.CREATE_TABLE_SCENE


        elif self.state == State.CREATE_TABLE_SCENE:

            if self.call_action("create_table_scene"):
                self.state = State.PLAN_GRASP


        elif self.state == State.PLAN_GRASP:

            if self.call_action("plan_grasp"):
                self.state = State.EXECUTE_GRASP


        elif self.state == State.EXECUTE_GRASP:

            if self.call_action("execute_grasp"):
                self.state = State.CLOSE_GRIPPER


        elif self.state == State.CLOSE_GRIPPER:

            if self.call_action("gripper_close"):
                self.state = State.VERIFY_GRASP


        elif self.state == State.VERIFY_GRASP:

            if self.call_action("verify_grasp"):
                self.state = State.LIFT


        elif self.state == State.LIFT:

            if self.call_action("lift"):
                self.state = State.WAIT_HAND


        elif self.state == State.WAIT_HAND:

            if self.hand_ready:
                self.state = State.COMPUTE_HANDOVER


        elif self.state == State.COMPUTE_HANDOVER:

            if self.call_action("compute_handover"):
                self.state = State.EXECUTE_HANDOVER


        elif self.state == State.EXECUTE_HANDOVER:

            if self.call_action("execute_handover"):
                self.state = State.OPEN_GRIPPER


        elif self.state == State.OPEN_GRIPPER:

            if self.call_action("gripper_open"):
                self.state = State.RETREAT


        elif self.state == State.RETREAT:

            if self.call_action("retreat"):
                self.state = State.RETURN_WORK_HOME


        elif self.state == State.RETURN_WORK_HOME:

            if self.call_action("return_work_home"):
                self.running = False
                self.state = State.IDLE
                self.get_logger().info(
                    "TASK FINISHED"
                )


def main(args=None):

    rclpy.init(args=args)

    node = PiperManager()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
