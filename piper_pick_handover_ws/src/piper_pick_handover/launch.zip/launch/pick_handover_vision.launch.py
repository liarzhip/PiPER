import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, LogInfo
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():

    project_share = get_package_share_directory(
        "piper_pick_handover"
    )

    pipeline_launch = os.path.join(
        project_share,
        "launch",
        "pick_handover_pipeline.launch.py",
    )

    pipeline = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            pipeline_launch
        )
    )

    return LaunchDescription(
        [
            LogInfo(
                msg=(
                    "VISION PIPELINE ONLY: "
                    "DaBai -> YOLO/MediaPipe -> target transform -> "
                    "target lock -> grasp target generation."
                )
            ),
            LogInfo(
                msg=(
                    "This launch does NOT start PIPER, MoveIt, "
                    "table collision, or execute robot motion."
                )
            ),
            pipeline,
        ]
    )
