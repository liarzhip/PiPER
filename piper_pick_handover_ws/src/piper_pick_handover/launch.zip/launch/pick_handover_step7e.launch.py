import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import LogInfo
from launch_ros.actions import Node


def generate_launch_description():

    share = get_package_share_directory(
        "piper_pick_handover"
    )

    return LaunchDescription(
        [
            LogInfo(
                msg=(
                    "STEP 7E MOTION ONLY: "
                    "Lift -> rotate gripper +Z toward Palm Initial -> "
                    "re-detect Palm Final -> Handover Approach -> "
                    "Handover Final. Vision stays separate."
                )
            ),

            Node(
                package="piper_pick_handover",
                executable="moveit_executor_node",
                name="moveit_executor_node",
                output="screen",
                parameters=[
                    os.path.join(
                        share,
                        "config",
                        "moveit_executor.yaml",
                    ),
                ],
            ),

            Node(
                package="piper_pick_handover",
                executable="table_scene_node",
                name="table_scene_node",
                output="screen",
                parameters=[
                    os.path.join(
                        share,
                        "config",
                        "table_scene.yaml",
                    ),
                ],
            ),

            Node(
                package="piper_pick_handover",
                executable="work_home_manager_node",
                name="work_home_manager_node",
                output="screen",
                parameters=[
                    os.path.join(
                        share,
                        "config",
                        "work_home.yaml",
                    ),
                ],
            ),

            Node(
                package="piper_pick_handover",
                executable="observe_hand_planner_node",
                name="observe_hand_planner_node",
                output="screen",
                parameters=[
                    os.path.join(
                        share,
                        "config",
                        "observe_hand.yaml",
                    ),
                ],
            ),

            Node(
                package="piper_pick_handover",
                executable="handover_planner_node",
                name="handover_planner_node",
                output="screen",
                parameters=[
                    os.path.join(
                        share,
                        "config",
                        "handover.yaml",
                    ),
                ],
            ),
        ]
    )
