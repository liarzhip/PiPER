import os
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    IncludeLaunchDescription,
    LogInfo,
    OpaqueFunction,
    RegisterEventHandler,
    TimerAction,
)
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


READY_SENTINEL = Path(
    "/tmp/piper_pick_handover_work_home_ready"
)


def _start_moveit_after_work_home(context, *args, **kwargs):
    del context, args, kwargs

    if not READY_SENTINEL.exists():
        return [
            LogInfo(
                msg=(
                    "[ERROR] WORK_HOME was not verified. "
                    "MoveIt will NOT be started."
                )
            )
        ]

    agx_moveit_share = get_package_share_directory(
        "agx_arm_moveit"
    )

    moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                agx_moveit_share,
                "launch",
                "demo.launch.py",
            )
        ),
        launch_arguments={
            "arm_type": "piper_x",
            "effector_type": "agx_gripper",

            # MoveIt/RViz follows the real arm state.
            "follow": "true",
            "feedback_topic": "/feedback/joint_states",
            "control_topic": "/control/joint_states",

            # Keep the physical control gate closed while idle;
            # open it automatically only for MoveIt execution.
            "auto_control_gate": "true",
            "control_gate_service": "/control_enable",

            "tcp_offset":
                "[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]",
        }.items(),
    )

    return [
        LogInfo(
            msg=(
                "WORK_HOME verified; /control_enable is CLOSED. "
                "Starting MoveIt with automatic Gate control."
            )
        ),
        moveit_launch,
        LogInfo(
            msg=(
                "Robot/MoveIt bringup complete. "
                "Vision is NOT started by this launch."
            )
        ),
    ]


def generate_launch_description():

    agx_ctrl_share = get_package_share_directory(
        "agx_arm_ctrl"
    )
    project_share = get_package_share_directory(
        "piper_pick_handover"
    )

    work_home_yaml = os.path.join(
        project_share,
        "config",
        "work_home.yaml",
    )

    # Stage 1: physical driver only.
    driver = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                agx_ctrl_share,
                "launch",
                "start_single_agx_arm.launch.py",
            )
        ),
        launch_arguments={
            "can_port": "can0",
            "arm_type": "piper_x",
            "effector_type": "agx_gripper",
            "fw_version": "v189",
            "auto_enable": "true",
            "speed_percent": "10",
            "control_enabled": "true",
            "tcp_offset":
                "[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]",
        }.items(),
    )

    # Stage 2: before MoveIt exists, move directly to WORK_HOME.
    startup_node = Node(
        package="piper_pick_handover",
        executable="work_home_startup_node",
        name="work_home_startup_node",
        output="screen",
        parameters=[
            work_home_yaml,
        ],
    )

    delayed_startup = TimerAction(
        period=2.5,
        actions=[
            startup_node,
        ],
    )

    # Stage 3: start MoveIt only after verified WORK_HOME + closed Gate.
    start_moveit = RegisterEventHandler(
        OnProcessExit(
            target_action=startup_node,
            on_exit=[
                OpaqueFunction(
                    function=_start_moveit_after_work_home
                )
            ],
        )
    )

    return LaunchDescription(
        [
            LogInfo(
                msg=(
                    "ROBOT BRINGUP ONLY: "
                    "PIPER driver -> WORK_HOME -> close Gate -> MoveIt."
                )
            ),
            LogInfo(
                msg=(
                    "WARNING: real robot will automatically move to "
                    "configured WORK_HOME."
                )
            ),
            LogInfo(
                msg=(
                    "Camera / YOLO / MediaPipe / target detection are "
                    "NOT started here."
                )
            ),
            driver,
            start_moveit,
            delayed_startup,
        ]
    )
