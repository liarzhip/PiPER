import os
from pathlib import Path

from ament_index_python.packages import (
    get_package_share_directory,
)
from launch import LaunchDescription
from launch.actions import (
    IncludeLaunchDescription,
    LogInfo,
    OpaqueFunction,
    RegisterEventHandler,
    TimerAction,
)
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import (
    PythonLaunchDescriptionSource,
)
from launch_ros.actions import Node


READY_SENTINEL = Path(
    "/tmp/piper_pick_handover_work_home_ready"
)


def _after_work_home(context, *args, **kwargs):
    del context, args, kwargs

    if not READY_SENTINEL.exists():
        return [
            LogInfo(
                msg=(
                    "WORK_HOME startup node exited without success sentinel. "
                    "MoveIt/project will NOT be started."
                )
            )
        ]

    agx_moveit_share = (
        get_package_share_directory(
            "agx_arm_moveit"
        )
    )
    project_share = (
        get_package_share_directory(
            "piper_pick_handover"
        )
    )

    moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                agx_moveit_share,
                "launch",
                "demo.launch.py",
            )
        ),
        launch_arguments={
            "arm_type": "piper_x",
            "effector_type": "agx_gripper",
            "follow": "true",
            "feedback_topic": "/feedback/joint_states",
            "control_topic": "/control/joint_states",

            # Automatic execution-period Gate.
            "auto_control_gate": "true",
            "control_gate_service": "/control_enable",

            "tcp_offset":
                "[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]",
            "use_rviz": "true",
        }.items(),
    )

    project_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                project_share,
                "launch",
                "pick_handover_step7c.launch.py",
            )
        )
    )

    return [
        LogInfo(
            msg=(
                "WORK_HOME verified and Gate CLOSED. "
                "Starting MoveIt with auto_control_gate:=true."
            )
        ),
        moveit_launch,

        # Give move_group/controller_manager/RViz time to initialize
        # before camera/perception/task nodes start.
        TimerAction(
            period=8.0,
            actions=[
                LogInfo(
                    msg=(
                        "MoveIt startup delay completed. "
                        "Starting perception/project pipeline."
                    )
                ),
                project_launch,
            ],
        ),
    ]


def generate_launch_description():

    agx_ctrl_share = (
        get_package_share_directory(
            "agx_arm_ctrl"
        )
    )
    project_share = (
        get_package_share_directory(
            "piper_pick_handover"
        )
    )

    work_home_yaml = os.path.join(
        project_share,
        "config",
        "work_home.yaml",
    )

    # ----------------------------------------------------------
    # Stage 1: real driver ONLY.
    # No MoveIt / ros2_control yet.
    # ----------------------------------------------------------

    driver = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                agx_ctrl_share,
                "launch",
                "start_single_agx_arm.launch.py",
            )
        ),
        launch_arguments={
            "can_port": "can0",
            "arm_type": "piper_x",
            "effector_type": "agx_gripper",
            "fw_version": "v189",
            "auto_enable": "true",
            "speed_percent": "10",
            "control_enabled": "true",
            "tcp_offset":
                "[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]",
        }.items(),
    )

    # Wait a little for CAN + feedback + enable.
    startup_node = Node(
        package="piper_pick_handover",
        executable="work_home_startup_node",
        name="work_home_startup_node",
        output="screen",
        parameters=[
            work_home_yaml,
        ],
    )

    delayed_startup = TimerAction(
        period=2.5,
        actions=[
            startup_node,
        ],
    )

    # ----------------------------------------------------------
    # Stage 2 starts ONLY after successful WORK_HOME arrival.
    # ----------------------------------------------------------

    start_after_home = RegisterEventHandler(
        OnProcessExit(
            target_action=startup_node,
            on_exit=[
                OpaqueFunction(
                    function=_after_work_home
                )
            ],
        )
    )

    return LaunchDescription(
        [
            LogInfo(
                msg=(
                    "PIPER Pick&Handover staged bringup: "
                    "driver -> WORK_HOME -> close Gate -> "
                    "MoveIt(auto Gate) -> perception."
                )
            ),
            LogInfo(
                msg=(
                    "WARNING: the robot will automatically move to "
                    "the configured WORK_HOME after the driver starts."
                )
            ),

            driver,
            start_after_home,
            delayed_startup,
        ]
    )
