import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    LogInfo,
)
from launch.launch_description_sources import (
    PythonLaunchDescriptionSource,
)
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    # --------------------------------------------------------------
    # Arguments
    # --------------------------------------------------------------

    can_port = LaunchConfiguration(
        "can_port"
    )
    arm_type = LaunchConfiguration(
        "arm_type"
    )
    effector_type = LaunchConfiguration(
        "effector_type"
    )
    fw_version = LaunchConfiguration(
        "fw_version"
    )
    speed_percent = LaunchConfiguration(
        "speed_percent"
    )
    auto_enable = LaunchConfiguration(
        "auto_enable"
    )
    follow = LaunchConfiguration(
        "follow"
    )
    auto_control_gate = LaunchConfiguration(
        "auto_control_gate"
    )

    # --------------------------------------------------------------
    # Package paths
    # --------------------------------------------------------------

    project_share = (
        get_package_share_directory(
            "piper_pick_handover"
        )
    )

    agx_ctrl_share = (
        get_package_share_directory(
            "agx_arm_ctrl"
        )
    )

    agx_moveit_launch = os.path.join(
        agx_ctrl_share,
        "launch",
        "start_single_agx_arm_moveit.launch.py",
    )

    project_pipeline_launch = os.path.join(
        project_share,
        "launch",
        "pick_handover_pipeline.launch.py",
    )

    moveit_executor_yaml = os.path.join(
        project_share,
        "config",
        "moveit_executor.yaml",
    )

    # --------------------------------------------------------------
    # AgileX real arm + MoveIt + RViz
    # --------------------------------------------------------------

    agx_moveit = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            agx_moveit_launch
        ),
        launch_arguments={
            "can_port": can_port,
            "arm_type": arm_type,
            "effector_type": effector_type,
            "fw_version": fw_version,
            "speed_percent": speed_percent,
            "auto_enable": auto_enable,
            "follow": follow,
            "auto_control_gate": auto_control_gate,
        }.items(),
    )

    # --------------------------------------------------------------
    # Existing STEP 2~5 pipeline
    # --------------------------------------------------------------

    pipeline = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            project_pipeline_launch
        )
    )

    # --------------------------------------------------------------
    # STEP 6 MoveIt planner bridge
    # --------------------------------------------------------------

    moveit_executor = Node(
        package="piper_pick_handover",
        executable="moveit_executor_node",
        name="moveit_executor_node",
        output="screen",
        parameters=[
            moveit_executor_yaml,
        ],
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "can_port",
                default_value="can0",
            ),
            DeclareLaunchArgument(
                "arm_type",
                default_value="piper_x",
            ),
            DeclareLaunchArgument(
                "effector_type",
                default_value="agx_gripper",
            ),
            DeclareLaunchArgument(
                "fw_version",
                default_value="v189",
            ),
            DeclareLaunchArgument(
                "speed_percent",
                default_value="15",
            ),
            DeclareLaunchArgument(
                "auto_enable",
                default_value="true",
            ),
            DeclareLaunchArgument(
                "follow",
                default_value="true",
            ),
            DeclareLaunchArgument(
                "auto_control_gate",
                default_value="true",
            ),

            LogInfo(
                msg=(
                    "Starting full PIPER-X Pick & Handover STEP 6: "
                    "real arm + MoveIt + RViz + perception + target pipeline."
                )
            ),
            LogInfo(
                msg=(
                    "MoveIt executor is PLAN-ONLY because "
                    "allow_execute=false in moveit_executor.yaml."
                )
            ),

            agx_moveit,
            pipeline,
            moveit_executor,
        ]
    )
